import { Navigate } from "react-router-dom";

export default function UserProtectedRoute({ children }) {

  const token = sessionStorage.getItem("userToken");

  return token
    ? children
    : <Navigate to="/" replace />;
}