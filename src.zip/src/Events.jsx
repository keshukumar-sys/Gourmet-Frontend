import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Events.css";

export default function Events() {

    const navigate = useNavigate();

    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [showDetailsModal, setShowDetailsModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [saving, setSaving] = useState(false);

    const today = new Date().toISOString().split("T")[0];

const clearEventData = () => {

  sessionStorage.removeItem("bookingData");
  sessionStorage.removeItem("selectedMenus");
  sessionStorage.removeItem("menuNotes");
  sessionStorage.removeItem("templateSettings");
  sessionStorage.removeItem("templateHTML");

  // old flag (keep for backward safety if any old tab exists)
  sessionStorage.removeItem("bookingInProgress");
  sessionStorage.removeItem("eventFlowId");

};


useEffect(() => {
  const flowId = sessionStorage.getItem("eventFlowId");

  // If no valid flow exists → clean stale data
  if (!flowId) {
    clearEventData();
  }
}, []);

useEffect(() => {

    const loadEvents = async () => {

        try {

            const response = await fetch(
                "/events",
                {
                    method: "GET",
                    headers: {
                        authorization: sessionStorage.getItem("userToken")
                    }
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to load events");
            }

            setEvents(
                data.sort(
                    (a, b) =>
                        new Date(b.eventdate) -
                        new Date(a.eventdate)
                )
            );

        } catch (err) {

            console.error(err);
            alert(err.message);

        } finally {

            setLoading(false);

        }

    };

    loadEvents();

}, []);

    // View complete event details
    const handleDetails = (event) => {
        setSelectedEvent(event);
        setShowDetailsModal(true);
        // console.log(JSON.stringify(event, null, 2));
    };

const handleEdit = (event) => {

    setSelectedEvent(
        JSON.parse(JSON.stringify(event))
    );

    setShowEditModal(true);

};


    
    return (
        <>
            <div className="event-container">

                <div className="event-header d-flex align-items-center justify-content-between">

                    <h1 className="event-heading">
                        Events
                    </h1>

                    <button
                    className="btn btn-success mb-5"
                    style={{ width:"7.5rem" }}

                    onClick={() => {

                        clearEventData();

                        sessionStorage.setItem("editMode", "false");

                        // ✅ CREATE NEW FLOW SESSION
                        const flowId = crypto.randomUUID();

                        sessionStorage.setItem("eventFlowId", flowId);
                        sessionStorage.setItem("bookingInProgress", "true");

                        navigate("/booking");

                    }}
                    >
                    Add Event
                    </button>

                </div>

                {
                    loading ? (

                        <h2 className="loading-text">
                            Loading...
                        </h2>

                    ) : events.length === 0 ? (

                        <h2 className="empty-text">
                            No Completed Events Found
                        </h2>

                    ) : (

                        <div className="event-list">

                            {
                                events.map((item, index) => {

                                    const eventDateTime = new Date(
                                        `${item.eventdate} ${item.time}`
                                    );

                                    const hoursRemaining =
                                        (eventDateTime - new Date()) /
                                        (1000 * 60 * 60);

                                    return (

                                        <div className="events-card" key={index}>

                                            <h2 className="event-name">
                                                {item.eventname}
                                            </h2>

                                            <p>
                                                <span>Name :</span> {item.username}
                                            </p>

                                            <p>
                                                <span>Mobile :</span> {item.mobnumber}
                                            </p>

                                            <p>
                                                <span>Date :</span> {item.eventdate}
                                            </p>

                                            <p>
                                                <span>Guests :</span> {item.guest}
                                            </p>

                                            <p>
                                                <span>Time :</span> {item.time}
                                            </p>

                                            <p>
                                                <span>Manager :</span> {item.manager}
                                            </p>

                                            <div className="event-buttons">

                                                <button
                                                    className="btn btn-primary"
                                                    onClick={() => handleDetails(item)}
                                                >
                                                    Details
                                                </button>

                                                <div className="edit-btn-wrapper">

                                                    {/* {editLocked && (
                                                        <span className="edit-tooltip">
                                                            Couldn't edit 48 hours before the Event
                                                        </span>
                                                    )} */}

                                                    <button
                                                        className="btn btn-warning"
                                                        // disabled={editLocked}
                                                        onClick={() => handleEdit(item)}
                                                    >
                                                        Edit
                                                        {/* {editLocked ? "❌ Edit" : "Edit"} */}
                                                    </button>

                                                </div>

                                            </div>

                                        </div>

                                    );
                                })
                            }

                        </div>

                    )
                }

            </div>

            {showDetailsModal && selectedEvent && (
                <div className="modal fade show d-block custom-modal">
                    <div className="modal-dialog  modal-xl">
                        <div className="modal-content custom-modal-content">

                            <div className="modal-header custom-modal-header">
                                <div>
                                    <h3 className="modal-title">
                                        🎉 Event Details
                                    </h3>
                                    <small>View complete event information</small>
                                </div>

                                <button
                                    className="btn-close btn-close-white"
                                    onClick={() => setShowDetailsModal(false)}
                                />
                            </div>

                            <div className="modal-body">

                                <div className="details-grid">

                                    <div className="info-card">
                                        <label>Event Name</label>
                                        <h5>{selectedEvent.eventname}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Customer</label>
                                        <h5>{selectedEvent.username}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Mobile Number</label>
                                        <h5>{selectedEvent.mobnumber}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Event Date</label>
                                        <h5>{selectedEvent.eventdate}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Guests</label>
                                        <h5>{selectedEvent.guest}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Time</label>
                                        <h5>{selectedEvent.time}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Manager</label>
                                        <h5>{selectedEvent.manager}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Selected Template</label>
                                        {selectedEvent.templateImage && (

                                        <img
                                        src={selectedEvent.templateImage}
                                        alt="template"
                                        style={{
                                            width:"120px",
                                            height:"120px",
                                            objectFit:"cover",
                                            borderRadius:"8px",
                                            marginTop:"10px"
                                        }}
                                        />

                                        )}                                        
                                        <h5>{selectedEvent.templateName || "No Template Selected"}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Additional Requirements</label>
                                        <h5 style={{whiteSpace:"pre-wrap", wordBreak:"break-word"}}>{selectedEvent.requirements || "N/A"}</h5>
                                    </div>

                                    <div className="info-card full-width">

                                        <label>Selected Menu</label>

                                        <div className="menu-category-wrapper">

                                            {selectedEvent.selectedMenu &&
                                            Object.entries(selectedEvent.selectedMenu)
                                                .filter(([_, items]) => items && items.length > 0)
                                                .map(([category, items]) => (
                                                <div
                                                    className="menu-category-card"
                                                    key={category}
                                                >
                                                    <h6>{category}</h6>

                                                    <ul>
                                                    {items.map((item, index) => (
                                                        <li key={index}>
                                                        {item}
                                                        </li>
                                                    ))}
                                                    </ul>
                                                </div>
                                                ))}

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div className="modal-footer">
                                <button
                                    className="btn premium-close-btn btn btn-danger"
                                    onClick={() => setShowDetailsModal(false)}
                                >
                                    Close
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            )}

            {showEditModal && selectedEvent && (
    <div className="modal fade show d-block custom-modal">
        <div className="modal-dialog  modal-xl">
            <div className="modal-content custom-modal-content">

                <div className="modal-header custom-modal-header">
                    <div>
                        <h3 className="modal-title">
                            ✏️ Edit Event
                        </h3>
                        <small>Update event information</small>
                    </div>

                    <button
                        className="btn-close btn-close-white"
                        onClick={() => setShowEditModal(false)}
                    />
                </div>

                <div className="modal-body">

                    <div className="edit-grid">

                        {/* Event Name */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Name
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.eventname}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        eventname: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Customer */}
                        <div className="input-card">
                            <label className="form-label">
                                Customer Name
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.username}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        username: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Mobile */}
                        <div className="input-card">
                            <label className="form-label">
                                Mobile Number
                            </label>

                            <input
                                type="number"
                                className="form-control premium-input"
                                value={selectedEvent.mobnumber}
                                onChange={(e) => {
                                let value = e.target.value;
                                if (!/^\d*$/.test(value)) return;
                                if (value.length > 10) {
                                    value = value.slice(0,10);
                                }
                                setSelectedEvent({
                                    ...selectedEvent,
                                    mobnumber:value
                                });
                                }}
                            />
                        </div>

                        {/* Date */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Date
                            </label>

                        <input
                            type="date"
                            className="form-control premium-input"
                            min={today}
                            value={selectedEvent.eventdate}
                            onChange={(e) =>
                                setSelectedEvent({
                                    ...selectedEvent,
                                    eventdate: e.target.value
                                })
                            }
                        />
                        </div>

                        {/* Guests */}
                        <div className="input-card">
                            <label className="form-label">
                                Guests
                            </label>

                            <input
                                type="number"
                                min={1}
                                className="form-control premium-input"
                                value={selectedEvent.guest}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        guest: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Time */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Time
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.time}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        time: e.target.value
                                    })
                                }
                            />
                        </div>

                        <div className="input-card full-width">
                            <label className="form-label">
                                Additional Requirements
                            </label>

                            <textarea
                                className="form-control premium-input"
                                maxLength={500}
                                value={selectedEvent.requirements || ""}
                                placeholder="Add your specific requirements"
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        requirements: e.target.value
                                    })
                                }
                            />

                            <p
                            style={{
                                textAlign: "right",
                                fontSize: "12px",
                                marginTop: "5px"
                            }}
                            >
                            {(selectedEvent.requirements || "").length}/500
                            </p>

                        </div>

                        <div className="input-card full-width">
                            <label className="form-label">
                                Current Template
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.templateName || "No Template Selected"}
                                readOnly
                            />
                        </div>

                        

                        {/* Manager */}
                        <div className="input-card full-width">
                            <label className="form-label">
                                Manager
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.manager}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        manager: e.target.value
                                    })
                                }
                            />
                        </div>

                    </div>

                </div>

                <div className="modal-footer">

                <button
                    className="btn btn-info"
                    onClick={() => {

                        // Start a fresh edit session
                        sessionStorage.removeItem("editMode");

                        const flowId = crypto.randomUUID();

                        sessionStorage.setItem("eventFlowId", flowId);
                        sessionStorage.setItem("bookingInProgress", "true");
                        sessionStorage.setItem("editMode", "true");

                        sessionStorage.setItem(
                        "bookingData",
                        JSON.stringify(selectedEvent)
                        );

                        navigate(
                            `/menuSelection/${selectedEvent._id}`,
                            {
                                state: {
                                    editMode: true,
                                    userType: "user",
                                    eventDetails: selectedEvent,
                                    selectedMenu: selectedEvent.selectedMenu || {},
                                    menuNotes: selectedEvent.menuNotes || {},
                                    template: selectedEvent.template || ""
                                }
                            }
                        );

                    }}
                >
                    Update Menu & Template
                </button>

                    <button
                        className="btn premium-cancel-btn btn btn-danger"
                        onClick={() => {
                            setShowEditModal(false);
                            setSelectedEvent(null);
                        }}
                    >
                        Cancel
                    </button>

                    <button
                        className="btn premium-save-btn"
                        disabled={saving}
                        onClick={async () => {

                            if (!selectedEvent.eventname.trim()) {
                                alert("Please enter Event Name");
                                return;
                            }

                            if (!selectedEvent.username.trim()) {
                                alert("Please enter Customer Name");
                                return;
                            }

                            if (!/^\d{10}$/.test(selectedEvent.mobnumber)) {
                                alert("Please enter a valid 10-digit Mobile Number");
                                return;
                            }

                            if (!selectedEvent.eventdate) {
                                alert("Please select Event Date");
                                return;
                            }

                            if (!selectedEvent.time) {
                                alert("Please select Event Time");
                                return;
                            }

                            if (!selectedEvent.guest || Number(selectedEvent.guest) <= 0) {
                                alert("Guest count must be greater than 0");
                                return;
                            }

                            if (!selectedEvent.manager.trim()) {
                                alert("Please enter Manager Name");
                                return;
                            }

                            try {

                                setSaving(true);

                                const response = await fetch(
                                    `/updateEvent/${selectedEvent._id}`,
                                    {
                                        method: "PUT",
                                        headers: {
                                            "Content-Type": "application/json",
                                            authorization: sessionStorage.getItem("userToken")
                                        },
                                        body: JSON.stringify(selectedEvent)
                                    }
                                );

                                const data = await response.json();

                                if (!response.ok) {
                                    throw new Error(
                                        data.message || "Failed to update event"
                                    );
                                }

                                alert(data.message || "Event Updated Successfully");

                                setEvents((prevEvents) =>
                                    prevEvents.map((event) =>
                                        event._id === selectedEvent._id
                                            ? { ...selectedEvent }
                                            : event
                                    )
                                );

                                setShowEditModal(false);
                                setSelectedEvent(null);

                            } catch (err) {

                                console.error(err);
                                alert(err.message || "Failed to update event");

                            } finally {

                                setSaving(false);

                            }

                        }}
                    >
                        {saving ? "Saving..." : "Save Changes"}
                    </button>

                </div>

            </div>
        </div>
    </div>
)}

        </>
    );
}