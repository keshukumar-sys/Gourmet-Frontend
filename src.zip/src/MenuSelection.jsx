import "./MenuSelection.css";
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";



export default function MenuSelection() {
  const navigate = useNavigate();
  const location = useLocation();

const [selectedMenus, setSelectedMenus] = useState(

  location.state?.selectedMenu ||

  JSON.parse(
    sessionStorage.getItem("selectedMenus")
  ) ||

  {}

);

const [loading, setLoading] = useState(false);

useEffect(() => {

  // Skip this check while editing
  if (location.state?.editMode) return;

  const flowId = sessionStorage.getItem("eventFlowId");
  const bookingData = sessionStorage.getItem("bookingData");

  if (!flowId || !bookingData) {

    navigate("/events", {
      replace: true
    });

  }

}, [navigate, location.state]);

const [menuNotes, setMenuNotes] = useState(

  location.state?.menuNotes ||

  JSON.parse(
    sessionStorage.getItem("menuNotes")
  ) ||

  {}

);

  const [openCategory, setOpenCategory] = useState(null);


const handleBack = () => {

  // New Event Creation
  if (!location.state?.editMode) {

    navigate("/booking", {
      state: {
        eventDetails: location.state?.eventDetails
      }
    });

  }

  // User Editing Event
  else if (location.state?.userType === "user") {

    navigate("/events");

  }

  // Admin Editing Event
  else {

    navigate("/allEvents");

  }

};


useEffect(() => {

  sessionStorage.setItem(

    "selectedMenus",

    JSON.stringify(selectedMenus)

  );

}, [selectedMenus]);


useEffect(() => {

  sessionStorage.setItem(

    "menuNotes",

    JSON.stringify(menuNotes)

  );

}, [menuNotes]);

const handleNoteChange = (item, note) => {
  setMenuNotes((prev) => ({
    ...prev,
    [item]: note,
  }));
};

const handleCheckboxChange = (category, item, checked) => {

  setSelectedMenus((prev) => {

    const currentItems = prev[category] || [];

    const updatedItems = checked
        ? [...new Set([...currentItems, item])]
        : currentItems.filter(menu => menu !== item);

    const newMenus = {
      ...prev,
      [category]: updatedItems,
    };

    if (updatedItems.length === 0) {
      delete newMenus[category];
    }

    return newMenus;
  });

  // Remove note when menu item is unchecked
  if (!checked) {

    setMenuNotes((prev) => {

      const updatedNotes = { ...prev };

      delete updatedNotes[item];

      return updatedNotes;

    });

  }

};
  
const handleNext = () => {

  const hasSelection = Object.values(selectedMenus).some(
    (items) => items.length > 0
  );

  if (!hasSelection) {
    alert("Please select at least one menu item.");
    return;
  }

  try {

    // Prevent multiple clicks
    setLoading(true);

    // Save latest menu selections
    sessionStorage.setItem(
      "selectedMenus",
      JSON.stringify(selectedMenus)
    );

    // Save latest menu notes
    sessionStorage.setItem(
      "menuNotes",
      JSON.stringify(menuNotes)
    );

    // Ensure latest booking data is preserved
    const bookingData = JSON.parse(
      sessionStorage.getItem("bookingData")
    );

    sessionStorage.setItem(
      "bookingData",
      JSON.stringify(bookingData)
    );

    navigate("/templateSelection", {
      state: {
        eventDetails: location.state?.eventDetails,
        selectedMenu: selectedMenus,
        menuNotes: menuNotes,
        editMode: location.state?.editMode || false,
        userType: location.state?.userType,
        eventId: location.state?.eventId
      }
    });

  } catch (err) {

    console.error(err);

    setLoading(false);

    alert("Something went wrong. Please try again.");

  }

};

const getFoodIcon = (category) => {
  if (category.includes("  ")) {
    return "/veg.jpeg";
  }

  if (category.includes(" ")) {
    return "/non.jpeg";
  }

  return null;
};

  const menuData = {
    "Oriental Main Course  ":[ //Done
      "Jasmine rice, green Thai vegetable curry, golden garlic, crisp bean sprout",
      "Teriyaki tofu, burnt garlic sticky rice, wakame sesame cabbage salad",
      "Soba noodles, edamame, tofu, asparagus in light miso broth, spring onion and toasted seaweed",
      "Nasi goreng, baby leek and asparagus skewers, pumpkin chips, peanut dip",
      "Mapo tofu, scallion rice",
      "Stir-fried Asian greens, pandaan rice"
    ],

    "Oriental Main Course ":[   //Done
      "Red Thai prawn curry, Jasmine rice, golden garlic, crisp bean sprout",
      "Stir-fried grouper in black bean sauce, Jasmine rice",
      "Steamed sea bass with lemon, coriander & garlic, Jasmine rice",
      "Balinese chicken, yellow rice, shallot sambal",
      "Fried chicken, dip",
      "Pork bulgogi, kimchee"
    ],

    "Salads": [ //Done
      "Baby spinach gomae salad with tofu, charcoal corn and togarashi",
      "Warm wild asparagus, sesame, ginger, light soy",
      "Fresh mozzarella, grilled chillies, mint and pine nuts",
      "Black quinoa, mixed herbs, toasted hazelnut, coconut, maple and rice vinegar dressing",
      "Grapefruit, blood orange, pickled ginger, ricotta and romaine",
      "Asparagus, roasted beet root, avocado, mixed greens, citrus Balsamic dressing"
    ],

    "Appetisers  ":[   //Done
      "Brioche baked vada pav",
      "Warm edamame and boiled peanut tarts with togarashi",
      "Avocado pillows, pickled poblano puree",
      "Cream cheese and water chestnut wonton, mango, chilli and coriander",
      "Avocado ceviche, young cucumber, mirin, golden onion",
      "Crisp rice cakes with miso glazed aubergines",
      "Truffle puffs with cheese and chilli bite",
      "Tandoori paneer, coriander pesto filling",
      "Malai paneer tikka, narangi ki chutney",
      "Warm Hormok phak ‘poori’",
      "Wild asparagus tart",
      "Sichuan pepper golden corn nibbles bird’s eye chilli",
      "Mushroom and truffle cream, brittle crisp",
      "Roasted beetroot galouti with feta centre, sheermal",
      "Phyllo wrapped Feta with flavoured honey"
    ],

    "Appetisers ":[   //Done
      "Creamy chicken and mushroom puff",
      "Keema pav with bacon thecha",
      "Atlantic salmon pillows, pickled poblano puree",
      "Beer batter fried fish fingers, Kaffir lime tartare",
      "Hamachi crudo, green tomato",
      "Dynamite shrimps",
      "Minced prawn balls coated with crisp wanton",
      "Tangra style chilli shrimps with pearl onion",
      "Vietnamese rolls “roast duck with anise”",
      "Murgh ke soole, lehsuni dahi ki chutney",
      "Bhunney murgh ke parchey",
      "Galouti kebab, ulte tawa ka paratha",
      "Mutton boti kebab",
      "Amritsari macchi, hara dhaniya chutney",
      "Butter fly prawn cutlet, kaffir lime, raw mango chutney"
    ],

    "Desserts": [ //Done
      "Sandesh tart",
      "Classic tres leche",
      "Tira mi sui",
      "Gulab jamun cheese cake",
      "Angoori rasmalai",
      "Vanilla bean crème brulee",
      "Zafrani Malpua, laccha rabri",
      "Salted chocolate and caramel tart",
      "Seasonal trifle, olive cake crumble",
      "Angoori rasmalai",
      "Ice cream sandwich, hot chocolate sauce, toasted cashew",
      "Mango sticky rice nigiri",
      "Tap tim krob"
    ],

    "Mini Sliders  ":[   //Done
      "Goat cheese and mushroom with arugula",      
      "Edamame, baby spinach, tomato and ricotta",      
      "Roast golden corn, pepper and cashew nut",      
      "Quinoa, parsley and cheese",     
      "Beetroot, potato, and toasted mixed seeds"      
    ],

    "Mini Sliders ":[   //Done
      "Smoked chicken and jalapeno",
      "Pulled chicken, bar-be-cue sauce",
      "Crisp chicken tenders, caramelised onion",
      "Minced lamb, cheddar",
      "Bull's eye burger, golden onion, chipotle chillies"
    ],

    "Dim Sum In Broth":[  //Done
      "Mushroom and celery in lemongrass broth (V)",
      "Water chestnut and asparagus in superior soy(v)",
      "Prawn and bamboo shoot in kombu dashi stock",
      "Chicken cilantro in superior soy"
    ],

    "Mediterranean Main Course  ":[  //Done
      "Classic hummus, tabouleh, labneh, falafel, pita and olives",
      "Avocado, wild asparagus, parsley, cucumber and jalapeno wraps, pickled vegetables",
      "Fusilli giganti with porcini and morel ragout, pine nuts, Parmesan",
      "Parmesan polenta, grilled winter roots, balsamic tomato",
      "Tomato and curry leaf risotto, goat cheese, sugar snap peas",
      "Cannelloni of roast vegetables, tomato ragout, basil",
      "Grilled corn puree, charred corn, baby leek crisps"
    ],

    "Mediterranean Main Course ":[  //Done
      "Pan seared snapper, bisque",
      "Chicken parmigiana",
      "Ham and green pea risotto, Chevre crumble",
      "Braised lamb shank, herb mash",
      "Spaetzle with chicken fricassee",
      "Spaghetti, chorizo and shrimp aglio olio"
    ],

    "Chaats":[  //Done
      "Palak patta aur bhindi ki chaat",
      "Burrata chaat",
      "Mango avocado sev poori",
      "Quinoa and lotus seed bhel",
      "Ram laddoo, laccha mooli, hara chutney",
      "Jhaal moori"
    ],  

    "Quiche  ":[   //Done
      "Wild asparagus and leek",
      "Farmed mushroom, truffle oil",
      "Edamame and water chestnut",
      "Brie and caramelised onion",
      "Broccoli and almond slivers"
    ],

    "Quiche ":[  //Done
      "Bacon and onion",
      "Chicken, green onion, cream cheese",
      "Shrimp and garlic, chilli and parmesan",
      "Minced lamb and scarmoza"
    ],

    "Indian Favourites  ":[  //Done
      "Green pea and potato cocktail samosa",
      "Khasta kachouri, saunth chutney",
      "Baked vada pav, thecha",
      "Mixed vegetable cutlet, ketchup sauce"
    ],

    "Wraps and Rolls  ":[  //Done
      "Smashed falafel, haloumi",
      "Cottage cheese chimichurri",
      "Black bean, avocado, chilli pepper wrap",
      "Masala potato, curry leaf, crisp onion"
    ],

    "Wraps and Rolls ":[  //Done
      "Kolkata chicken kathi roll",
      "Galouti, paratha",
      "Murgh khurchan in roomali",
      "Malabari paratha, mutton ghee roast"
    ],

    "Indian Favourites ":[  //Done
      "Chicken/Mutton patti samosa",
      "Chicken cutlet",
      "Masala fish finger, green chilli and peanut dip",
      "Dimer devil, onion- kasundi"
    ],

    "Indian Main Course  ":[   //Done
      "Pulled jackfruit bhuna, kulcha, kheera and cream cheese raita",
      "Malabari paratha tacos, paneer ghee roast, inji puli",
      "Nadru yakhni, doon chetin, Basmati",
      "Smoked tomato makhani with tadka burrata, multigrain paratha",
      "Masala mini kachouri, kadhi, sev aur saunth",
      "Appam/neer dosai, idiyappam, mushroom pepper fry",
      "Khade masaley ka dal, tawa paratha, tadka pyaz",
      "Paneer malai roll with santrey ki chutney"
    ],

    "Indian Main Course ":[   //Done
      "Rillette of kasha mangsho, luchi, ‘kasundi kachumber",
      "Gobindo bhog” polao, Bhetki macher paturi, khejur-tomato chutney",
      "Kheema ghotala, tikona paratha, hari mirch ka salad",
      "Malabar prawn curry, unpolished rice, mango-ginger relish",
      "Chicken pepper fry, paratha, peanut chutney",
      "Murgh ka khurchan roll",
      "Rawa fried surmai, kasundi onion",
      "Butter garlic prawn, kokum"
    ],

    "The Mediterranean Spread":[    //Done
      "Hummus, butternut squash, arugula, roasted pepper",
      "Mixed berry labneh",
      "Phyllo wrapped feta arugula",
      "Marinated olives, lavache",
      "Preserved lemon and ricotta flat bread",
      "Charred wild mushroom, parmesan, rocket",
      "Baby potatoes, rosemary",
    ],

    "Temari  ":[   //Done
      "Pickled ginger, radish, gochujang",
      "Bell pepper, sesame miso",
      "Zucchini, smoked chilli",
      "Spinach, edamame"
    ],

    "Temari ":[   //Done
      "Salmon, cream cheese, tobanjan",
      "Spicy tuna",
      "Hamachi, yuzu mayo",
      "Spinach, edamame"
    ],

    "Flatbreads  ":[   //Done
      "Tomato, basil, bocconcini, pinenuts",
      "Smashed avocado, sun-dried tomato, goat cheese, arugula",
      "Wild mushroom, parsley, pearl onion, Parmesan"
    ],

    "Mini Sandwiches  ":[    //Done
      "Cucumber, dill and cream cheese fingers",
      "Spiced bocconcini, slow roasted tomato and basil on focaccia",
      "Mozzarella, Cheddar and green chilli on toast",
      "Goat cheese, avocado, celery, walnut pesto and water cress"
    ],

    "Mini Sandwiches ":[    //Done
      "Grilled honey glazed ham and cheese",
      "Roast chicken, mustard, red onion, Cheddar",
      "Pulled lamb, cream cheese, jalapeno and romaine",
      "Egg and ‘kasundi’ fingers"
    ],

    "Flatbreads ":[   //Done
      "Chicken, bacon, red onion, sour cream",
      "Minced lamb, mint, Feta and pine nuts",
      "Pepperoni"
    ],
    
    "Refreshing Thirst Quenchers":[
      "Smoked kairi panna, chilli raw mango",
      "Dhungar masala chaas, methi nimki",
      "Lemongrass and kaffir lime shikanji, chilled pomelo",
      "Pomegranate, dilli “kala chaat” masala",
      "Hazelnut ‘espresso’ cold coffee",
      "Kaffir lime mojito"
    ],

    "The Antipasti Table":[
      "Roasted baby aubergines garlic and feta, chilli and thyme",
      "Zucchini rolls filled with goat cheese and arugula, extra virgin olive oil",
      "Rosemary and chilli marinated olives",
      "Avocado, heirloom tomato and bocconcini",
      "Beetroot and cream cheese spread caraway seeds, lavache",
      "Slow roasted tomato, mozzarella and basil",
      "Grilled peppers marjoram, parmesan",
      "Marinated mixed mushroom tarragon"
    ],
  };

  return (
    <div className="menu-container">
      <h1 className="menu-title">Select Menu Items</h1>

   
  {/* Desktop Layout */}
  <div className="menu-grid desktop-menu">
    {Object.entries(menuData).map(([category, items], index) => (
      <div key={index} className="menu-card">
        <h2 className="menus-heading">
          {category}

          {getFoodIcon(category) && (
            <img
              src={getFoodIcon(category)}
              alt=""
              className="food-type-icon"
            />
          )}
        </h2>

        <ul style={{ listStyle: "none", padding: 0 }}>
          {items.map((item, i) => (
            <li key={i} className="menu-item-wrapper">
              <label
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: "10px",
                  cursor: "pointer",
                }}
              >
                <input
                  type="checkbox"
                  checked={
                    selectedMenus[category]?.includes(item) || false
                  }
                  onChange={(e) =>
                    handleCheckboxChange(
                      category,
                      item,
                      e.target.checked
                    )
                  }
                />

                <span style={{ fontSize: "1rem" }}>
                  {item}
                </span>
              </label>

              {selectedMenus[category]?.includes(item) && (
                <div className="note-popup">
                  <textarea
                    className="desktop-note-box"
                    placeholder="Add special note..."
                    value={menuNotes[item] || ""}
                    onChange={(e) =>
                      handleNoteChange(item, e.target.value)
                    }
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    ))}
  </div>

  {/* Mobile Accordion Layout */}
  <div className="mobile-menu">
    {Object.entries(menuData).map(([category, items]) => (
      <div key={category} className="accordion-category">

        <div
          className="accordion-header"
          onClick={() =>
            setOpenCategory(
              openCategory === category ? null : category
            )
          }
        >
          <div className="accordion-title">
            <h3 style={{fontSize:"1.3rem"}}>{category}</h3>

            {getFoodIcon(category) && (
              <img
                src={getFoodIcon(category)}
                alt=""
                className="food-type-icon"
              />
            )}
          </div>

          <span className="accordion-arrow">
            {openCategory === category ? "▲" : "▼"}
          </span>
        </div>

        {openCategory === category && (
          <div className="accordion-content">

          {items.map((item, i) => (
            <div key={i} className="accordion-item-wrapper">

              <label className="accordion-item">

                <input
                  type="checkbox"
                  checked={
                    selectedMenus[category]?.includes(item) || false
                  }
                  onChange={(e) =>
                    handleCheckboxChange(
                      category,
                      item,
                      e.target.checked
                    )
                  }
                />

                <span
                  style={{
                    color: "#fff",
                    fontSize: "0.85rem",
                  }}
                >
                  {item}
                </span>

              </label>

              {selectedMenus[category]?.includes(item) && (
                <textarea
                  className="mobile-note-box"
                  placeholder="Add special note..."
                  value={menuNotes[item] || ""}
                  onChange={(e) =>
                    handleNoteChange(item, e.target.value)
                  }
                />
              )}

            </div>
          ))}

          </div>
        )}
      </div>
    ))}
  </div>

<div
  style={{
    textAlign: "center",
    marginTop: "30px",
    marginBottom: "30px",
    display: "flex",
    justifyContent: "center",
    gap: "15px"
  }}
>

  <button
    onClick={handleBack}
    disabled={loading}
    style={{
      padding: "12px 30px",
      fontSize: "16px",
      cursor: "pointer",
      borderRadius: "8px",
      border: "none",
      backgroundColor: "#dc3545",
      color: "#fff",
    }}
  >
    ← Back
  </button>

  <button
    onClick={handleNext}
    disabled={loading}
    style={{
      padding: "12px 30px",
      fontSize: "16px",
      cursor: loading ? "not-allowed" : "pointer",
      borderRadius: "8px",
      border: "none",
      backgroundColor: loading ? "#6c757d" : "#007bff",
      color: "#fff",
      opacity: loading ? 0.7 : 1,
    }}
  >
    {loading ? "Loading..." : "Next →"}
  </button>

</div>
    </div>
  );
}