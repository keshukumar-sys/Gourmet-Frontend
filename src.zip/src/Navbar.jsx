import { Link, useNavigate } from "react-router-dom"
import { NavLink } from "react-router-dom"
import "./Navbar.css";
import { useState } from "react";

export default function Navbar(){

    const navigate = useNavigate();
    const token = sessionStorage.getItem("userToken")
    const adminToken = sessionStorage.getItem("adminToken")

    const adminLogout = () =>{
        sessionStorage.removeItem("adminToken")
        sessionStorage.removeItem("userToken")
        alert("Admin Logout Successfull")
        navigate("/admin")
    }

    const userLogout = () =>{
        sessionStorage.removeItem("userToken")
        alert("Logout Successfull")
        navigate("/")
    }

    const [menuOpen, setMenuOpen] = useState(false);

    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };

    const closeMenu = () => {
        setMenuOpen(false);
    };

    return(
        <>
            <nav className=" navbar navbar-expand-lg d-flex justify-content-between " style={{padding:"0.5rem 2rem"}}>
                
                <h1 className=" text-light" style={{fontSize:"1.8rem"}}>
                    <img src="/1.png" alt="Logo" style={{width:"150px"}}/>
                </h1>

                <div className="menu-icon" onClick={toggleMenu}>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                <div className={`nav-wrapper ${menuOpen ? "active" : ""} d-flex align-items-center justify-content-evenly`}>
                    {!token && !adminToken ? (
                        <>
                        <ul className="navbar1 nav navbar-nav">

                            <li className=" nav-item"> 
                                <NavLink to = "/"
                                onClick={closeMenu}
                                className={({isActive})=>
                                isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                Login
                                </NavLink>
                            </li>

                            <li className=" nav-item"> 
                                <NavLink to = "/admin"
                                onClick={closeMenu}
                                className={({isActive})=>
                                isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                Admin
                                </NavLink>
                            </li>
                        </ul>
                        </>
                    ):token ? (
                        <>
                            <ul className="navbar1 nav navbar-nav">

                                <li className=" nav-item"> 
                                    <NavLink to = "/events"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Events
                                    </NavLink>
                                </li>

                                {/* <li className=" nav-item"> 
                                    <NavLink to = "/booking"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Booking
                                    </NavLink>
                                </li>

                                <li className=" nav-item"> 
                                    <NavLink to = "/menuSelection"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Menu-Selection
                                    </NavLink>
                                </li>

                                <li className=" nav-item"> 
                                    <NavLink to = "/templateSelection"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Template-Selection
                                    </NavLink>
                                </li> */}

                                <button className="btn btn-danger logout" onClick={userLogout}><label>Logout</label></button>
                            </ul>
                        </>
                    ):(
                        <>
                            <ul className="navbar1 nav navbar-nav">
                                  
                                <li className=" nav-item"> 
                                    <NavLink to = "/allEvents"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    All-Events
                                    </NavLink>
                                </li>      

                                {/* <li className=" nav-item"> 
                                    <NavLink to = "/addTemplate"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Add-Templates
                                    </NavLink>
                                </li>   
                                   

                                <li className=" nav-item"> 
                                    <NavLink to = "/temp"
                                    onClick={closeMenu}
                                    className={({isActive})=>
                                    isActive? "nav-link active-link" : "nav-link inactive-link"}>
                                    Temp
                                    </NavLink>
                                </li>         */}

                                <button className="btn logout btn-danger" onClick={adminLogout}><label>Logout</label></button>
                            </ul>
                        </>
                    )}
                </div>

            </nav>
        </>
    )
}   