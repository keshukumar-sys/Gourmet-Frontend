import { useEffect, useState } from "react";
import "./AllEvents.css";
import { useNavigate, NavLink } from "react-router-dom"

export default function AllEvents() {

    const navigate = useNavigate()
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);


    const [selectedEvent, setSelectedEvent] = useState(null);
    const [showDetailsModal, setShowDetailsModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [templates, setTemplates] = useState([]);




    useEffect(() => {
    fetch("/templates")
        .then(res => res.json())
        .then(data => setTemplates(data))
        .catch(err => console.log(err));
}, []);

    useEffect(() => {

        const token =
            sessionStorage.getItem("adminToken");

            fetch("/allEvents", {
                headers: {
                    authorization: token
                }
            })
            .then(res => res.json())
            .then(data => {

                // Ensure data is an array
                if (!Array.isArray(data)) {
                    setEvents([]);
                    setLoading(false);
                    return;
                }

                const today = new Date();

                const sortedEvents = [...data].sort((a, b) => {

                    const dateA = new Date(a.eventdate);
                    const dateB = new Date(b.eventdate);

                    const diffA = dateA.getTime() - today.getTime();
                    const diffB = dateB.getTime() - today.getTime();

                    const isPastA = diffA < 0;
                    const isPastB = diffB < 0;

                    // Past events go to bottom
                    if (isPastA && !isPastB) return 1;
                    if (!isPastA && isPastB) return -1;

                    // Upcoming events nearest first
                    if (!isPastA && !isPastB) {
                        return diffA - diffB;
                    }

                    // Past events latest first
                    return dateB - dateA;
                });

                setEvents(sortedEvents);
                setLoading(false);
            })
            .catch(err => {
                console.log(err);
                setLoading(false);
            });

    }, []);

    

    if (loading) {
        return <h2>Loading Events...</h2>;
    }

    const handleDetails = (event) => {
        setSelectedEvent(event);
        setShowDetailsModal(true);
    };

    const handleEdit = (event) => {
        setSelectedEvent(event);
        setShowEditModal(true);
    };

    const getTemplateName = (templateId) => {
        const template = templates.find(t => t._id === templateId);
        return template ? template.templateName : "No Template Selected";
    };

    return (
        <div className="allevents-container">

            <h1>All Events</h1>

            <div className=" d-flex align-items-center justify-content-end gap-2">
                <NavLink to="/createUser" className="">
                    <button className="btn btn-success margin-bottom-2">Create-User</button>
                </NavLink>

                <NavLink to="/createAdmin" className="">
                    <button className="btn btn-success margin-bottom-2">Create-Admin</button>
                </NavLink>

                    <NavLink to="/addTemplate">
                        <button className="btn btn-primary">Add Template</button>
                    </NavLink>
            </div>

            {events.length === 0 ? (
                <h3 className=" text-light text-center">No Events Found</h3>
            ) : (
                events.map((event, index) => {

                    const today = new Date();
                    const eventDate = new Date(event.eventdate);

                    const isPast = eventDate < today;

                    return (
                        <div
                            key={event._id || index}
                            className="event-card"
                            style={{
                                opacity: isPast ? 0.6 : 1,
                                border: "1px solid #ddd",
                                padding: "15px",
                                margin: "10px 0",
                                borderRadius: "10px"
                            }}
                        >
                            <h3>{event.eventname}</h3>

                            <p>
                                <strong>Name:</strong> {event.username}
                            </p>

                            <p>
                                <strong>Email:</strong> {event.email}
                            </p>

                            <p>
                                <strong>Mobile:</strong> {event.mobnumber}
                            </p>

                            <p>
                                <strong>Date:</strong> {event.eventdate}
                            </p>

                            <p>
                                <strong>Time:</strong> {event.time}
                            </p>

                            <p>
                                <strong>Guests:</strong> {event.guest}
                            </p>

                            <p>
                                <strong>Manager:</strong> {event.manager}
                            </p>

                            {isPast ? (
                                <span style={{ color: "red", background:"#fff", padding:"0.5rem" }}>
                                    Completed
                                </span>
                            ) : (
                                <span style={{ color: "green", background:"#fff", padding:"0.5rem" }}>
                                    Upcoming
                                </span>
                            )}

                            <br /><br />

                            <div className="event-actions">

                                <button
                                    onClick={() => handleDetails(event)}
                                    className="details-btn btn btn-info"
                                >
                                    Details
                                </button>

                                <button
                                    onClick={() => handleEdit(event)}
                                    className="edit-btn btn btn-warning"
                                >
                                    Edit
                                </button>

                            </div>
                        </div>
                    );
                })
            )}

            {showDetailsModal && selectedEvent && (
                <div className="modal fade show d-block custom-modal">
                    <div className="modal-dialog  modal-xl">
                        <div className="modal-content custom-modal-content">

                            <div className="modal-header custom-modal-header">
                                <div>
                                    <h3 className="modal-title">
                                        🎉 Event Details
                                    </h3>
                                    <small>View complete event information</small>
                                </div>

                                <button
                                    className="btn-close btn-close-white"
                                    onClick={() => setShowDetailsModal(false)}
                                />
                            </div>

                            <div className="modal-body">

                                <div className="details-grid">

                                    <div className="info-card">
                                        <label>Event Name</label>
                                        <h5>{selectedEvent.eventname}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Customer</label>
                                        <h5>{selectedEvent.username}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Mobile Number</label>
                                        <h5>{selectedEvent.mobnumber}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Event Date</label>
                                        <h5>{selectedEvent.eventdate}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Guests</label>
                                        <h5>{selectedEvent.guest}</h5>
                                    </div>

                                    <div className="info-card">
                                        <label>Time</label>
                                        <h5>{selectedEvent.time}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Manager</label>
                                        <h5>{selectedEvent.manager}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Selected Template</label>
                                        {selectedEvent.templateImage && (

                                        <img
                                        src={selectedEvent.templateImage}
                                        alt="template"
                                        style={{
                                            width:"120px",
                                            height:"120px",
                                            objectFit:"cover",
                                            borderRadius:"8px",
                                            marginTop:"10px"
                                        }}
                                        />

                                        )}                                        
                                        <h5>{selectedEvent.templateName || "No Template Selected"}</h5>
                                    </div>

                                    <div className="info-card full-width">
                                        <label>Additional Requirements</label>
                                        <h5 style={{whiteSpace:"pre-wrap", wordBreak:"break-word"}}>{selectedEvent.requirements || "N/A"}</h5>
                                    </div>

                                    <div className="info-card full-width">

                                        <label>Selected Menu</label>

                                        <div className="menu-category-wrapper">

                                            {selectedEvent.selectedMenu &&
                                                Object.entries(selectedEvent.selectedMenu).map(
                                                    ([category, items]) => (
                                                        <div
                                                            className="menu-category-card"
                                                            key={category}
                                                        >
                                                            <h6>{category}</h6>

                                                            <ul>
                                                                {items.map((item, index) => (
                                                                    <li key={index}>
                                                                        {item}
                                                                    </li>
                                                                ))}
                                                            </ul>

                                                        </div>
                                                    )
                                                )}

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div className="modal-footer">
                                <button
                                    className="btn premium-close-btn btn btn-danger"
                                    onClick={() => setShowDetailsModal(false)}
                                >
                                    Close
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            )}

            {showEditModal && selectedEvent && (
    <div className="modal fade show d-block custom-modal">
        <div className="modal-dialog  modal-xl">
            <div className="modal-content custom-modal-content">

                <div className="modal-header custom-modal-header">
                    <div>
                        <h3 className="modal-title">
                            ✏️ Edit Event
                        </h3>
                        <small>Update event information</small>
                    </div>

                    <button
                        className="btn-close btn-close-white"
                        onClick={() => setShowEditModal(false)}
                    />
                </div>

                <div className="modal-body">

                    <div className="edit-grid">

                        {/* Event Name */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Name
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.eventname}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        eventname: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Customer */}
                        <div className="input-card">
                            <label className="form-label">
                                Customer Name
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.username}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        username: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Mobile */}
                        <div className="input-card">
                            <label className="form-label">
                                Mobile Number
                            </label>

                            <input
                                type="number"
                                className="form-control premium-input"
                                value={selectedEvent.mobnumber}
                                onChange={(e) => {
                                let value = e.target.value;
                                if (!/^\d*$/.test(value)) return;
                                if (value.length > 10) {
                                    value = value.slice(0,10);
                                }
                                setSelectedEvent({
                                    ...selectedEvent,
                                    mobnumber:value
                                });
                                }}
                            />
                        </div>

                        {/* Date */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Date
                            </label>

                            <input
                                type="date"
                                className="form-control premium-input"
                                value={selectedEvent.eventdate}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        eventdate: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Guests */}
                        <div className="input-card">
                            <label className="form-label">
                                Guests
                            </label>

                            <input
                                type="number"
                                className="form-control premium-input"
                                value={selectedEvent.guest}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        guest: e.target.value
                                    })
                                }
                            />
                        </div>

                        {/* Time */}
                        <div className="input-card">
                            <label className="form-label">
                                Event Time
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.time}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        time: e.target.value
                                    })
                                }
                            />
                        </div>

                        <div className="input-card full-width">
                            <label className="form-label">
                                Additional Requirements
                            </label>

                            <textarea
                                className="form-control premium-input"
                                maxLength={500}
                                value={selectedEvent.requirements || ""}
                                placeholder="Add your specific requirements"
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        requirements: e.target.value
                                    })
                                }
                            />

                            <p
                            style={{
                                textAlign: "right",
                                fontSize: "12px",
                                marginTop: "5px"
                            }}
                            >
                            {(selectedEvent.requirements || "").length}/500
                            </p>

                        </div>

                        <div className="input-card full-width">
                            <label className="form-label">
                                Current Template
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={getTemplateName(selectedEvent.template)}
                                readOnly
                            />
                        </div>

                        

                        {/* Manager */}
                        <div className="input-card full-width">
                            <label className="form-label">
                                Manager
                            </label>

                            <input
                                type="text"
                                className="form-control premium-input"
                                value={selectedEvent.manager}
                                onChange={(e) =>
                                    setSelectedEvent({
                                        ...selectedEvent,
                                        manager: e.target.value
                                    })
                                }
                            />
                        </div>

                    </div>

                </div>

                <div className="modal-footer">

                    <button
  className="btn btn-info"
  onClick={() => {

    navigate(`/menuSelection/${selectedEvent._id}`, {
      state: {
        editMode: true,
        userType: "admin",

        eventId: selectedEvent._id,

        eventDetails: selectedEvent,

        selectedMenu: selectedEvent.selectedMenu || {},

        menuNotes: selectedEvent.menuNotes || {},

        template: selectedEvent.template || ""
      }
    });

  }}
>
  Update Menu & Template
</button>

                    <button
                        className="btn premium-cancel-btn btn btn-danger"
                        onClick={() => setShowEditModal(false)}
                    >
                        Cancel
                    </button>

                    <button
                        className="btn premium-save-btn"
                        onClick={async () => {

                            try {

                                const response = await fetch(
                                    `/updateEvent/${selectedEvent._id}`,
                                    {
                                        method: "PUT",
                                        headers: {
                                            "Content-Type": "application/json",
                                            authorization:
                                                sessionStorage.getItem("adminToken")
                                        },
                                        body: JSON.stringify(selectedEvent)
                                    }
                                );

                                const data = await response.json();

                                alert(
                                    data.message ||
                                    "Event Updated Successfully"
                                );

                                setEvents(
                                    events.map(event =>
                                        event._id === selectedEvent._id
                                            ? selectedEvent
                                            : event
                                    )
                                );

                                setShowEditModal(false);

                            } catch (err) {

                                console.log(err);
                                alert("Failed to update event");

                            }

                        }}
                    >
                        Save Changes
                    </button>

                </div>

            </div>
        </div>
    </div>
)}

        </div>
    );
}