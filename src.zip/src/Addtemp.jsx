import React, { useState, useEffect } from "react";
import "./Addtemp.css";

function Addtemp() {

    const [templateName, setTemplateName] = useState("");
    const [selectedTemplates, setSelectedTemplates] = useState([]);
    
    const [templateImage, setTemplateImage] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [defaultTextColor, setDefaultTextColor] = useState("#ffffff");

    const [templates, setTemplates] = useState([]);

    const token = sessionStorage.getItem("adminToken");

    // Fetch templates
    const fetchTemplates = async () => {
        try {
            const response = await fetch("/templates");
            const data = await response.json();
            setTemplates(data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        fetchTemplates();
    }, []);

    // Handle image upload + preview
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setTemplateImage(file);

        if (file) {
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    // Submit template
    const handleSubmit = async (e) => {
        e.preventDefault();

        console.log("Admin Token =", token);

        try {
            const formData = new FormData();

            formData.append("templateName", templateName);
            formData.append("templateImage", templateImage);
            formData.append("defaultTextColor", defaultTextColor);

            const response = await fetch(
                "/addTemplate",
                {
                    method: "POST",
                    headers: {
                        authorization: token
                    },
                    body: formData
                }
            );

                console.log("Response Status =", response.status);

                const data = await response.json();

                console.log("Response Data =", data);

                alert(data.message);

            if (data.message === "Template Added Successfully") {
                setTemplateName("");
                setTemplateImage(null);
                setPreviewUrl(null);
                setDefaultTextColor("#ffffff");
                fetchTemplates();
            }

        } catch (error) {
            console.log(error);
            alert("Failed to add template");
        }
    };

    const handleTemplateSelect = (id) => {

    if (selectedTemplates.includes(id)) {

        setSelectedTemplates(
            selectedTemplates.filter(
                item => item !== id
            )
        );

    } else {

        setSelectedTemplates([
            ...selectedTemplates,
            id
        ]);

    }

};

const deleteSelectedTemplates = async () => {
    try {
        const count = selectedTemplates.length;

        for (const id of selectedTemplates) {
            await fetch(
                `/deleteTemplate/${id}`,
                {
                    method: "PUT",
                    headers: {
                        authorization: token
                    }
                }
            );
        }

        setSelectedTemplates([]);
        fetchTemplates();

        if (count === 1) {
            alert("Selected Template Deleted Successfully");
        } else {
            alert("Selected Templates Deleted Successfully");
        }

    } catch (error) {
        console.log(error);
        alert("Failed to delete templates");
    }
};

    // Delete template
    const deleteTemplate = async (id) => {
        try {
            const response = await fetch(
                `/deleteTemplate/${id}`,
                {
                    method: "PUT",
                    headers: {
                        authorization: token
                    }
                }
            );

            const data = await response.json();
            console.log("DELETE RESPONSE =", data);
            alert(data.message);

            fetchTemplates();

        } catch (error) {
            console.log(error);
        }
    };

    const handleCheckboxChange = (id) => {
    setSelectedTemplates(prev =>
        prev.includes(id)
            ? prev.filter(t => t !== id)
            : [...prev, id]
    );
};

    return (

        <div className="addtemp-page">

            <div className="addtemp-container">

                <h2 className="addtemp-title">
                    Add Template
                </h2>

                <form
                    className="addtemp-form"
                    onSubmit={handleSubmit}
                >

                    {/* Template Name */}
                    <div className="form-group">
                        <label className="form-label">
                            Template Name
                        </label>

                        <input
                            type="text"
                            className="custom-input text-dark"
                            value={templateName}
                            onChange={(e) =>
                                setTemplateName(e.target.value)
                            }
                            required
                        />
                    </div>

                    {/* Image Upload */}
                    <div className="form-group">
                        <label className="form-label">
                            Template Image
                        </label>

                        <input
                            type="file"
                            className="custom-input"
                            accept="image/*"
                            onChange={handleImageChange}
                            required
                        />
                    </div>

                    {/* Preview */}
                    {previewUrl && (
                        <div style={{ marginBottom: "15px" }}>
                            <img
                                src={previewUrl}
                                alt="preview"
                                style={{
                                    width: "200px",
                                    borderRadius: "8px",
                                    border: "1px solid #ddd"
                                }}
                            />
                        </div>
                    )}

                    {/* Default Text Color */}
                    <div className="form-group">
                        <label className="form-label">
                            Default Text Color
                        </label>

                        <div
                            style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "10px"
                            }}
                        >
                            {/* Color Picker */}
                            <input
                                type="color"
                                value={defaultTextColor}
                                onChange={(e) =>
                                    setDefaultTextColor(e.target.value)
                                }
                            />

                            {/* Hex Code Input */}
                            <input
                                type="text"
                                className="custom-input text-dark"
                                value={defaultTextColor}
                                placeholder="#ffffff"
                                onChange={(e) =>
                                    setDefaultTextColor(e.target.value)
                                }
                                style={{
                                    width: "120px"
                                }}
                            />
                        </div>
                    </div>

                    <button
                        className="add-btn"
                        type="submit"
                    >
                        Add Template
                    </button>

                </form>

                <div className="section-divider"></div>

                <div
                    style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: "20px",
                        flexDirection:"column"
                    }}
                >
                    <h3 className="available-title text-light">
                        {templates.length === 0 ? "No Templates" : "Available Templates"}
                    </h3>

                    {selectedTemplates.length > 0 && (
                        <button
                            type="button"
                            className="delete-btn"
                            onClick={deleteSelectedTemplates}
                        >
                            Delete Selected
                        </button>
                    )}
                </div>

                <div className="template-grid">
                {templates.map((temp) => (
                    <div key={temp._id} className="template-item">

                    <div className="template-selection-card">

                        <div className="checkbox-img">
                            <div className="checkbox-wrapper">
                                <input
                                    type="checkbox"
                                    checked={selectedTemplates.includes(temp._id)}
                                    onChange={() => handleCheckboxChange(temp._id)}
                                />

                                <img
                                src={temp.previewImage}
                                className="template-image"
                                alt="template"
                                />
                             </div>
                        </div>

                        {/* <img
                        src={temp.previewImage}
                        className="template-image"
                        alt="template"
                        /> */}

                        <div className="template-body">
                        <h3>{temp.templateName}</h3>
                        <p>Text Color: {temp.defaultTextColor}</p>
                        </div>

                    </div>

                    </div>
                ))}
                </div>

            </div>

        </div>
    );
}

export default Addtemp;