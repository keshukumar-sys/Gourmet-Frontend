import React, { useState, useEffect } from "react";
import "./AddMenu.css";

function AddMenu() {

    const [menuName, setMenuName] = useState("");
    const [price, setPrice] = useState("");
    const [category, setCategory] = useState("");
    const [menuImage, setMenuImage] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);

    const [menus, setMenus] = useState([]);
    const [selectedMenus, setSelectedMenus] = useState([]);

    const token = sessionStorage.getItem("adminToken");

    // Fetch menus
    const fetchMenus = async () => {
        try {
            const res = await fetch("http://localhost:3040/menus");
            const data = await res.json();
            setMenus(data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        fetchMenus();
    }, []);

    // Image change
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setMenuImage(file);

        if (file) {
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    // Add menu
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const formData = new FormData();
            formData.append("menuName", menuName);
            formData.append("price", price);
            formData.append("category", category);
            formData.append("menuImage", menuImage);

            const res = await fetch("http://localhost:3040/addMenu", {
                method: "POST",
                headers: {
                    authorization: token
                },
                body: formData
            });

            const data = await res.json();
            alert(data.message);

            if (data.message === "Menu Added Successfully") {
                setMenuName("");
                setPrice("");
                setCategory("");
                setMenuImage(null);
                setPreviewUrl(null);

                fetchMenus();
            }

        } catch (error) {
            console.log(error);
            alert("Failed to add menu");
        }
    };

    // Checkbox
    const handleCheckboxChange = (id) => {
        setSelectedMenus(prev =>
            prev.includes(id)
                ? prev.filter(item => item !== id)
                : [...prev, id]
        );
    };

    // Delete selected
    const deleteSelectedMenus = async () => {
        try {
            const count = selectedMenus.length;

            for (const id of selectedMenus) {
                await fetch(`http://localhost:3040/deleteMenu/${id}`, {
                    method: "PUT",
                    headers: {
                        authorization: token
                    }
                });
            }

            setSelectedMenus([]);
            fetchMenus();

            alert(
                count === 1
                    ? "Menu Deleted Successfully"
                    : "Menus Deleted Successfully"
            );

        } catch (error) {
            console.log(error);
        }
    };

    return (
        <div className="addmenu-page">

            <div className="addmenu-container">

                <h2 className="addmenu-title">Add Menu</h2>

                {/* FORM */}
                <form className="addmenu-form" onSubmit={handleSubmit}>

                    <input
                        type="text"
                        placeholder="Category"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        required
                    />

                    <input
                        type="text"
                        placeholder="Menu Name"
                        value={menuName}
                        onChange={(e) => setMenuName(e.target.value)}
                        required
                    />

                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        required
                    />

                    {previewUrl && (
                        <img
                            src={previewUrl}
                            alt="preview"
                            className="preview-img"
                        />
                    )}

                    <button type="submit" className="add-btn">
                        Add Menu
                    </button>

                </form>

                <div className="section-divider"></div>

                <div className="menu-header">
                    <h3 className=" text-light">
                        {menus.length === 0 ? "No Menus" : "Available Menus"}
                    </h3>
                    

                    {selectedMenus.length > 0 && (
                        <button
                            className="delete-btn"
                            onClick={deleteSelectedMenus}
                        >
                            Delete Selected
                        </button>
                    )}
                </div>

                {/* MENU LIST */}
                <div className="menu-grid">

                    {menus.map((menu) => (
                        <div key={menu._id} className="menu-card">

                            <input
                                type="checkbox"
                                checked={selectedMenus.includes(menu._id)}
                                onChange={() => handleCheckboxChange(menu._id)}
                            />

                            <img src={menu.menuImage} alt="menu" />

                            <h3>{menu.menuName}</h3>
                            <p>₹{menu.price}</p>
                            <p>{menu.category}</p>

                        </div>
                    ))}

                </div>

            </div>

        </div>
    );
}

export default AddMenu;