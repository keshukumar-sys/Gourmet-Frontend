import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Admin.css";

export default function Admin() {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // If admin already logged in, redirect immediately
  useEffect(() => {

    const token = sessionStorage.getItem("adminToken");

    if (token) {
      navigate("/allEvents", {
        replace: true
      });
    }

  }, [navigate]);

  const submitForm = async (e) => {

    e.preventDefault();

    try {

      const response = await fetch(
        "/adminLogin",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            email,
            password
          })
        }
      );

      const data = await response.json();

      if (data.token) {

        sessionStorage.setItem(
          "adminToken",
          data.token
        );

        alert(data.message || "Login Successful");

        setEmail("");
        setPassword("");

        navigate("/allEvents", {
          replace: true
        });

      } else {

        alert(data.message);

      }

    } catch (err) {

      console.log(err);
      alert("Login Failed");

    }

  };

  return (
    <div className="admin-container">

      <div className="admin-card">

        <div className="admin-form">

          <h1 className="logo">Admin Panel</h1>

          <h2>Welcome Admin</h2>

          <p>Please login to continue</p>

          <form onSubmit={submitForm}>

            <input
              type="email"
              placeholder="Admin Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <button type="submit">
              Login
            </button>

          </form>

        </div>

      </div>

    </div>
  );
}