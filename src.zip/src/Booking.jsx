import { useState, useEffect } from "react";
import { useNavigate, NavLink  } from "react-router-dom";
import "./Booking.css";

export default function Booking() {

  const navigate = useNavigate();


useEffect(() => {

const flowId = sessionStorage.getItem("eventFlowId");
const isBookingInProgress = sessionStorage.getItem("bookingInProgress");

  if (!isBookingInProgress || !flowId) {

    navigate("/events", {
      replace: true
    });

    return;

  }

  sessionStorage.setItem(
    "bookingInProgress",
    "true"
  );

}, [navigate]);


useEffect(() => {

  const handlePageShow = () => {

const flowId = sessionStorage.getItem("eventFlowId");
const isBookingInProgress = sessionStorage.getItem("bookingInProgress");

    if (!isBookingInProgress || !flowId) {

      navigate("/events", {
        replace: true
      });

    }

  };

  window.addEventListener(
    "pageshow",
    handlePageShow
  );

  return () => {

    window.removeEventListener(
      "pageshow",
      handlePageShow
    );

  };

}, [navigate]);


const flowId = sessionStorage.getItem("eventFlowId");

const isEditMode =
  sessionStorage.getItem("editMode") === "true";

const savedData = isEditMode
  ? JSON.parse(sessionStorage.getItem("bookingData")) || {}
  : {};

const [username, setUsername] = useState(savedData.username || "");
const [mobnumber, setNumber] = useState(savedData.mobnumber || "");
const [eventname, setEventname] = useState(savedData.eventname || "");
const [eventdate, setEventdate] = useState(savedData.eventdate || "");
const [guest, setGuest] = useState(savedData.guest || "");
const [time, setTime] = useState(savedData.time || "");
const [manager, setManager] = useState(savedData.manager || "");
const [requirements, setRequirements] = useState(savedData.requirements || "");
const [numberMsg, setNumberMsg] = useState("");


useEffect(() => {

  const bookingData = {
    username,
    mobnumber,
    eventname,
    eventdate,
    guest,
    time,
    manager,
    requirements
  };

  sessionStorage.setItem(
    "bookingData",
    JSON.stringify(bookingData)
  );

}, [
  username,
  mobnumber,
  eventname,
  eventdate,
  guest,
  time,
  manager,
  requirements
]);

const handleNext = (e) => {

    e.preventDefault();

    if (!username.trim()) {
        alert("Please enter Full Name");
        return;
    }

    if (mobnumber.length !== 10) {
        alert("Please enter a valid 10 digit Mobile Number");
        return;
    }

    if (!eventname.trim()) {
        alert("Please enter Event Name");
        return;
    }

    if (!eventdate) {
        alert("Please select Event Date");
        return;
    }

    if (!time.trim()) {
        alert("Please enter Event Time");
        return;
    }

    if (!guest || Number(guest) <= 0) {
        alert("Guest count must be greater than 0");
        return;
    }
    
    if (!manager.trim()) {
        alert("Please enter Manager Name");
        return;
    }

    const eventDetails = {
        username: username.trim(),
        mobnumber,
        eventname: eventname.trim(),
        eventdate,
        guest,
        time: time.trim(),
        manager: manager.trim(),
        requirements: requirements.trim()
    };

    sessionStorage.setItem(
        "bookingData",
        JSON.stringify(eventDetails)
    );

    navigate("/menuSelection", {
        state: {
            eventDetails
        }
    });

};

  return (
    <>
      <div className="booking-container">

        <div className="booking-card">

          {/* HEADER */}
          <div className="booking-header">
            <h1>Book Your Event</h1>

            <p>
              Fill in the details and our team will contact you shortly
            </p>
          </div>

          {/* FORM */}
          <form className="booking-form" onSubmit={handleNext}>

            <div className="input-group">
              <label>Full Name</label>

              <input
                type="text"
                placeholder="Enter Full Name"
                value={username}
                required
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Mobile Number</label>

            <input
                type="tel"
                placeholder="Enter Mobile Number"
                value={mobnumber}
                required
                onChange={(e) => {
                    let value = e.target.value;

                    // allow only numbers
                    if (!/^\d*$/.test(value)) return;

                    // ❌ hard limit: max 10 digits only
                    if (value.length > 10) {
                        value = value.slice(0, 10);
                    }

                    setNumber(value);

                    if (value.length < 10) {
                        setNumberMsg("Number must be 10 digits");
                    } else {
                        setNumberMsg("");
                    }
                }}
            />

            {mobnumber.length > 0 && mobnumber.length < 10 && (
                <p style={{ color: "white", fontSize: "13px", marginTop: "5px" }}>
                    {numberMsg}
                </p>
            )}
            </div>

            <div className="input-group">
              <label>Event Name</label>

              <input
                type="text"
                placeholder="Enter Event Name"
                value={eventname}
                required
                onChange={(e) => setEventname(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Event Date</label>

              <input
                type="date"
                value={eventdate}
                required
                min={new Date().toISOString().split("T")[0]}
                onChange={(e) => setEventdate(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Number of Guests</label>

              <input
                type="number"
                min="1"
                placeholder="Enter Guests Count"
                value={guest}
                required
                onChange={(e) => setGuest(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Event Time</label>

              <input
                type="text"
                placeholder="Eg: 8.00pm - 10.00pm"
                value={time}
                required
                onChange={(e) => setTime(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Event Manager</label>

              <input
                type="text"
                placeholder="Manager Name"
                required
                value={manager}
                onChange={(e) => setManager(e.target.value)}
              />
            </div>
            

            <div className="input-group full-width">
              <label>Additional Requirements</label>

              <textarea
                rows="4"
                maxLength="500"
                placeholder="Enter any special request..."
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
              />

              <p
                  style={{
                    textAlign: "right",
                    marginTop: "5px",
                    fontSize: "12px",
                    color: "#fff"
                  }}
                >
                  {requirements.length}/500
                </p>
            </div>

            <div className="button-section">

                <button
                    type="button"
                    onClick={() => navigate("/events")}
                >
                    ← Back
                </button>

                <button
                    type="submit"
                >
                    Next →
                </button>

            </div>

          </form>

        </div>

      </div>
    </>
  );
}