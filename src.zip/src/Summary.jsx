import { useLocation, useNavigate, NavLink } from "react-router-dom";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import "./Summary.css"
import { useEffect, useState } from "react";

export default function Summary() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
const menuNotes = location.state?.menuNotes || {};
const [submitting, setSubmitting] = useState(false);

useEffect(() => {

  const isEdit =
    location.state?.editMode ||
    sessionStorage.getItem("editMode") === "true";

  // While editing an existing event, don't validate booking flow
  if (isEdit) {
    return;
  }

  const flowId = sessionStorage.getItem("eventFlowId");
  const bookingData = sessionStorage.getItem("bookingData");

  if (!flowId || !bookingData) {
    navigate("/events", {
      replace: true
    });
  }

}, [navigate, location.state]);

const {

  eventDetails,

  template,

  templateName,

  templateImage,

  selectedMenu,

  editMode,

  eventId,

  userType

} = location.state || {};

  if (!location.state) {
    return <h2>No Data Found</h2>;
  }

const downloadPDF = async () => {

  const html =
    sessionStorage.getItem("templateHTML");

  if (!html) {
    alert("No template found");
    return;
  }

  const tempDiv =
    document.createElement("div");

  tempDiv.innerHTML = html;

  tempDiv.style.position = "absolute";
  tempDiv.style.left = "-9999px";

  document.body.appendChild(tempDiv);

  const cards =
    tempDiv.querySelectorAll(".template-card");

 const pdf = new jsPDF({
  orientation: "p",
  unit: "mm",
  format: [359.039, 218.016]
});

  for (let i = 0; i < cards.length; i++) {

    const canvas = await html2canvas(cards[i], {
      scale: 3,
      useCORS: true
    });

    const imgData =
      canvas.toDataURL("image/png");

    if (i > 0) {
  pdf.addPage([359.039, 218.016]);
}

    pdf.addImage(
  imgData,
  "PNG",
  0,
  0,
  218.016,
  359.039
);
  }

  document.body.removeChild(tempDiv);

  pdf.save("MenuCard.pdf");
};

const getFoodType = (category) => {
  if (category.includes("  ")) {
    return {
      label: "",
      icon: "/veg.jpeg"
    };
  }

  if (category.includes(" ")) {
    return {
      label: "",
      icon: "/non.jpeg"
    };
  }

  return null;
};

const handleSubmit = async () => {

  if (submitting) return;
  setSubmitting(true);

  try {



    console.log({

      ...eventDetails,

      selectedMenu,

      menuNotes,

      template,

      templateImage,

      templateName

    });

    const token = sessionStorage.getItem("userToken");

    const response = await fetch(

      "/bookingevents",

      {

        method: "POST",

        headers: {

          "Content-Type": "application/json",

          authorization: token

        },

        body: JSON.stringify({

          ...eventDetails,

          selectedMenu,

          menuNotes,

          template,

          templateName,

          email: sessionStorage.getItem("email")

        })

      }

    );

    const data = await response.json();

    console.log("Status =", response.status);

console.log("Response =", data);  

    if (!response.ok) {

      return alert(

        data.message ||

        "Something went wrong"

      );

    }

    sessionStorage.removeItem("bookingData");

    sessionStorage.removeItem("selectedMenus");

    sessionStorage.removeItem("menuNotes");

    sessionStorage.removeItem("templateSettings");

    sessionStorage.removeItem("templateHTML");

    sessionStorage.removeItem("bookingInProgress");

    sessionStorage.removeItem("eventFlowId");

    alert("Event Submitted Successfully");

    navigate(

      "/events",

      {

        replace: true

      }

    );

  }

  catch (err) {

    console.log(err);

    alert(

      "Failed to submit event"

    );

  }
  finally {

  setSubmitting(false);

}

};


const handleBack = () => {

  navigate("/templateSelection", {
    state: {
      eventDetails,
      template,
      templateName,
      templateImage,
      selectedMenu,
      menuNotes,
      editMode,
      eventId,
      userType
    }
  });

};


const handleUpdateEvent = async () => {

  if (submitting) return;

  setSubmitting(true);

  const token =
    userType === "admin"
      ? sessionStorage.getItem("adminToken")
      : sessionStorage.getItem("userToken");

  try {

    const response = await fetch(
      `/updateEvent/${eventId}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          authorization: token
        },
        body: JSON.stringify({

          ...eventDetails,

          template,

          templateName,

          templateImage,

          selectedMenu,

          menuNotes

        })
      }
    );

    const data = await response.json();

    if (!response.ok) {

      alert(
        data.message ||
        "Failed to update event"
      );

      return;
    }

    sessionStorage.removeItem("bookingData");
    sessionStorage.removeItem("selectedMenus");
    sessionStorage.removeItem("menuNotes");
    sessionStorage.removeItem("templateSettings");
    sessionStorage.removeItem("templateHTML");
    sessionStorage.removeItem("bookingInProgress");
    sessionStorage.removeItem("eventFlowId");

    alert(
      data.message ||
      "Event Updated Successfully"
    );

    navigate(
      userType === "admin"
        ? "/allEvents"
        : "/events"
    );

  } catch (err) {

    console.log(err);

    alert("Failed to update event");

  } finally {

    setSubmitting(false);

  }

};

  return (
    <div 
    style={{
    backgroundColor: "#164764",
    minHeight: "100vh",
    padding:"2rem"
  }}>
    <div
      className="summary-container"
      style={{
        maxWidth: "1000px",
        margin: "20px auto",
        padding: "20px",
      }}
    >
      <h1 className="text-center mb-4">
        Event Summary
      </h1>

      <div
        className="summary-card"
        style={{
          border: "1px solid #ddd",
          padding: "20px",
          borderRadius: "10px",
          background: "#fff"
        }}
      >
        <h2>Event Details</h2>

        <p>
          <strong>Name:</strong>{" "}
          {eventDetails?.username}
        </p>

        <p>
          <strong>Mobile:</strong>{" "}
          {eventDetails?.mobnumber}
        </p>

        <p>
          <strong>Event Name:</strong>{" "}
          {eventDetails?.eventname}
        </p>

        <p>
          <strong>Date:</strong>{" "}
          {eventDetails?.eventdate}
        </p>

        <p>
          <strong>Time:</strong>{" "}
          {eventDetails?.time}
        </p>

        <p>
          <strong>Manager:</strong>{" "}
          {eventDetails?.manager}
        </p>

        <p>
          <strong>Guests:</strong>{" "}
          {eventDetails?.guest}
        </p>

        <p>
          <strong>Requirements:</strong>{" "}
          {eventDetails?.requirements || ""}
        </p>

        <hr />

        <h2>Selected Menu Items</h2>

        {
          selectedMenu &&
          Object.entries(selectedMenu).map(
            ([category, items]) => (

              <div
                key={category}
                style={{ marginBottom: "20px"}}
              >

<div
  style={{
    display: "flex",
    alignItems: "center",
    gap: "10px",
    marginBottom: "10px",
    flexWrap: "wrap"
  }}
>
  <h3
    style={{
      color: "#2c3e50",
      fontSize: "1.3rem",
      margin: 0
    }}
  >
    {category.trim()}
  </h3>

  {getFoodType(category) && (
    <>
      <img
        src={getFoodType(category).icon}
        alt={getFoodType(category).label}
        style={{
          width: "18px",
          height: "18px",
          objectFit: "contain"
        }}
      />

      <span
        style={{
          fontSize: "0.9rem",
          fontWeight: "600",
          color: "#666"
        }}
      >
        {getFoodType(category).label}
      </span>
    </>
  )}
</div>

                <ul>
                  {
                    items.map((item, index) => (
                      <li key={index} style={{fontSize:"0.95rem" }}>
                        {item}
                      </li>
                    ))
                  }
                </ul>

              </div>

            )
          )
        }

        <hr />

        <h2>Selected Template</h2>

        {templateImage && (
          <div className="template-summary-box">

            <p className="template-summary-name">
              - {templateName || template}
            </p>

            <img
              src={templateImage}
              alt="Selected Template"
              className="template-summary-image"
            />

          </div>
        )}

        <br />

        <hr />

        <div className="summary-btn-container">

          <button
            className="back-btn"
            onClick={handleBack}
            disabled={submitting}
          >
            ← Back
          </button>

          <button
            className="download-btn"
            onClick={downloadPDF}
            disabled={submitting}

          >
            Download PDF
          </button>

          {editMode ? (
            <button
              className="submit-btn"
              onClick={handleUpdateEvent}
              disabled={submitting}
            >
              {submitting ? "Updating..." : "Update Event"}
            </button>
          ) : (
            <button
              className="submit-btn"
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? "Submitting..." : "Submit"}
            </button>
          )}

        </div>
      </div>
    </div>
    </div>
  );
}