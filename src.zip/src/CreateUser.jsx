import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useNavigate } from "react-router-dom"
import "./CreateUser.css";

export default function SignUp() {

  const navigate = useNavigate()
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mob, setMob] = useState("");
  const [manager, setManager] = useState("");
  const [password, setPassword] = useState("");

  const submitForm = (e) => {
    e.preventDefault();
    
    const token =
        sessionStorage.getItem("adminToken");

    if(name==="" || email==="" || password===""){
        alert("Fill the Empty Fields")
    }

    fetch("/admincc", {
        method:"POST",
        headers:{
            "Content-Type":"application/json",
                    authorization: token
        },
        body:JSON.stringify({
            name:name,
            email:email,
            mob:mob,
            manager:manager,
            password:password
        })
    })
    .then(res=>res.json())
    .then(data=>{
        
        //if(data === "Login Successfully")
        //data = message stored in data in by using node.js code eg: res.send("Login Successfully") 

if(data.token){ //Doubt
    alert("SignUp Successfull") 
    sessionStorage.setItem("userToken", data.token)
    navigate("/allEvents")

    setTimeout(() => {

        sessionStorage.removeItem("userToken")

        alert("Session Expired. Please Login")

        navigate("/")

    }, 3600000)
    
    // setEmail("");
    // setPassword("");
}
else{
    alert(data.message)
}
})
    .catch(err=>console.log(err))
    setName("");
    setEmail("");
    setMob("");
    setManager("");
    setPassword("");
  }

  

  return (
    <div className="cc-container">

      <div className=" d-flex justify-content-start w-100 px-5">
        <NavLink to="/allEvents">
          <button className="btn btn-secondary">
            ← Back
          </button>
        </NavLink>
      </div>

      <div className="cc-card">

        {/* LEFT SIDE */}
        <div className="form-section">
          <h1>Hello Admin.</h1>
          <p>Fill the details to Create User.</p>

          <form onSubmit={submitForm}>
            <input
              type="text"
              placeholder="Full Name"
              value={name}
              required="true"
              onChange={(e)=>setName(e.target.value)}
            />

            <input
              type="email"
              placeholder="Email"
              value={email}
              required="true"
              onChange={(e)=>setEmail(e.target.value)}
            />

            <input
              type="number"
              placeholder="Contact no."
              value={mob}
              required="true"
              onChange={(e)=>setMob(e.target.value)}
            />

            <input
              type="text"
              placeholder="Event Manager"
              value={manager}
              required="true"
              onChange={(e)=>setManager(e.target.value)}
            />

            <input
            //   type="password"
              placeholder="Password"
              value={password}
              required="true"
              onChange={(e)=>setPassword(e.target.value)}
            />

            <button type="submit">Create User</button>
          </form>

          

          
            
          
        </div>

      </div>

    </div>
  );
}