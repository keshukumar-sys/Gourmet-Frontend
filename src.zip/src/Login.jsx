import { useState, useEffect } from "react";
import { useNavigate, NavLink } from "react-router-dom";
import "./Login.css";

export default function Login() {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Prevent logged-in users from accessing Login page
useEffect(() => {
  const token = sessionStorage.getItem("userToken");

  if (token) {
    navigate("/events", { replace: true });
  }
}, []);

  const submitForm = (e) => {

    e.preventDefault();

    fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email,
        password
      })
    })
      .then(res => res.json())
      .then(data => {

        if (data.token) {

          sessionStorage.setItem(
            "userToken",
            data.token
          );

          // optional if you need email later
          sessionStorage.setItem(
            "email",
            email
          );

          alert("Login Successful");

          setEmail("");
          setPassword("");

          navigate("/events", {
            replace: true
          });

        } else {

          alert(
            data.message || "Login Failed"
          );

        }

      })
      .catch(err => {
        console.log(err);
        alert("Something went wrong");
      });

  };

  return (
    <div className="login-container">

      <div className="login-card">

        <div className="login-form">

          <h1 className="logo1">
            Social Catering
          </h1>

          <h2>
            Welcome Back
          </h2>

          <p>
            Sign in with your email and password
          </p>

          <form onSubmit={submitForm}>

            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
              required
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) =>
                setPassword(e.target.value)
              }
              required
            />

            <button type="submit">
              Login
            </button>

            <p className="signup-text">

              <NavLink to="/forgotPassword">
                Forgot Password ?
              </NavLink>

            </p>

          </form>

        </div>

      </div>

    </div>
  );
}