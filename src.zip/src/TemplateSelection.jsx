import React, { useRef, useEffect, useState, useLayoutEffect } from "react";
import "./templateSelection.css";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import {useLocation, useNavigate}from "react-router-dom";
import { useParams } from "react-router-dom";


import template1 from "./assets/template1.jpg"
import template2 from "./assets/template2.jpg"

function App() {

  const location = useLocation();
  const navigate = useNavigate();
  const eventId = location.state?.eventDetails?._id;
  const incomingMenu =

    location.state?.selectedMenu ||

    JSON.parse(
      sessionStorage.getItem("selectedMenus")
    ) ||

    {};

  const incomingMenuNotes =

    location.state?.menuNotes ||

    JSON.parse(
      sessionStorage.getItem("menuNotes")
    ) ||

    {};
  const userType = location.state?.userType || "user";

  const [loading, setLoading] = useState(false);

useEffect(() => {

  // Skip validation while editing an existing event
  if (location.state?.editMode) return;

  const flowId = sessionStorage.getItem("eventFlowId");
  const bookingData = sessionStorage.getItem("bookingData");
  const bookingInProgress = sessionStorage.getItem("bookingInProgress");

  if (!flowId || !bookingData || !bookingInProgress) {

    navigate("/events", {
      replace: true
    });

  }

}, [navigate, location.state]);
  

useEffect(() => {

  if (!eventId) return;

  fetch(

    `/event/${eventId}`,

    {

      headers: {

        authorization:

          sessionStorage.getItem("adminToken")

          ||

          sessionStorage.getItem("userToken")

      }

    }

  )

  .then(res => res.json())

  .then(data => {

      setEventDetails(data);

      setTemplate(data.template);

  })

  .catch(err => console.log(err));

}, [eventId]);

const [eventDetails, setEventDetails] = useState(
  JSON.parse(
    sessionStorage.getItem(
      "bookingData"
    )
  ) || null
);

useEffect(() => {
  if(eventDetails){
    sessionStorage.setItem(
      "bookingData",
      JSON.stringify(eventDetails)
    );
  }
}, [eventDetails]);

  const editMode = location.state?.editMode || false;
  const [templates, setTemplates] = useState([]);

  useEffect(() => {

    fetch("/templates")
        .then(res => res.json())
      .then(data=>{

      setTemplates(data);

      const saved =
      JSON.parse(
      sessionStorage.getItem(
      "templateSettings"
      )
      );

      if(saved?.template){
      setTemplate(saved.template);
      }

      else if(
      location.state?.eventDetails
      ?.template
      ){

      setTemplate(
      location.state.eventDetails
      .template
      );

      }

      else if(data.length){
      setTemplate(data[0]._id);
      }

      })
        .catch(err => console.log(err));

}, []);

  const [template, setTemplate] = useState("");

const currentTemplate =
templates.find(
  temp =>
  String(temp._id)
  ===
  String(template)
)
||
null;


const templateList = templates.map(temp => temp._id);

const prevTemplate = () => {
  const currentIndex = templateList.indexOf(template);

  setTemplate(
    templateList[
      currentIndex === 0
        ? templateList.length - 1
        : currentIndex - 1
    ]
  );
};

const nextTemplate = () => {
  const currentIndex = templateList.indexOf(template);

  setTemplate(
    templateList[
      currentIndex === templateList.length - 1
        ? 0
        : currentIndex + 1
    ]
  );
};

  const [headingsize, setHeadingsize] = useState("");
  const [headingfont, setHeadingfont] = useState("SilkSerif");

const headingFonts = [
  "SilkSerif",
  "Cormorant2"
];

const prevHeadingFont = () => {
  const currentIndex =
    headingFonts.indexOf(headingfont);

  setHeadingfont(
    headingFonts[
      currentIndex === 0
        ? headingFonts.length - 1
        : currentIndex - 1
    ]
  );
};

const nextHeadingFont = () => {
  const currentIndex =
    headingFonts.indexOf(headingfont);

  setHeadingfont(
    headingFonts[
      currentIndex === headingFonts.length - 1
        ? 0
        : currentIndex + 1
    ]
  );
};

  const [fontsize, setFontsize] = useState("");
  const [font, setFont] = useState("Monsterrat");

  const itemFontList = ["Monsterrat", "Futura"];

const prevItemFont = () => {
  const currentIndex = itemFontList.indexOf(font);

  setFont(
    itemFontList[
      currentIndex === 0
        ? itemFontList.length - 1
        : currentIndex - 1
    ]
  );
};

const nextItemFont = () => {
  const currentIndex = itemFontList.indexOf(font);

  setFont(
    itemFontList[
      currentIndex === itemFontList.length - 1
        ? 0
        : currentIndex + 1
    ]
  );
};

  useEffect(() => {

  const savedTemplate =

    JSON.parse(
      sessionStorage.getItem("templateSettings")
    ) || {};

  if (savedTemplate.template) {

    setTemplate(savedTemplate.template);

  }

  if (savedTemplate.headingsize) {

    setHeadingsize(
      savedTemplate.headingsize
    );

  }

  if (savedTemplate.headingfont) {

    setHeadingfont(
      savedTemplate.headingfont
    );

  }

  if (savedTemplate.fontsize) {

    setFontsize(
      savedTemplate.fontsize
    );

  }

  if (savedTemplate.font) {

    setFont(
      savedTemplate.font
    );

  }

}, []);

useEffect(() => {

  sessionStorage.setItem(

    "templateSettings",

    JSON.stringify({

      template,

      headingsize,

      headingfont,

      fontsize,

      font

    })

  );

}, [

  template,

  headingsize,

  headingfont,

  fontsize,

  font

]);

const handleBack = () => {

  sessionStorage.setItem(
    "templateSettings",
    JSON.stringify({
        template,
        headingsize,
        headingfont,
        fontsize,
        font
    })
);

    navigate("/menuSelection", {

        state: {

            eventDetails,

            selectedMenu: incomingMenu,

            menuNotes: incomingMenuNotes,

            userType,

            editMode

        }

    });

};

const handlePreview = () => {

  // Prevent double click
  if (loading) return;

  setLoading(true);

  try {

    // Save current template settings
    sessionStorage.setItem(
      "templateSettings",
      JSON.stringify({
        template,
        headingsize,
        headingfont,
        fontsize,
        font
      })
    );

    // Save template HTML
    const templateHTML =
      document.querySelector(".templates-wrapper")?.innerHTML;

    sessionStorage.setItem(
      "templateHTML",
      templateHTML
    );

    // Save latest menu selections
    sessionStorage.setItem(
      "selectedMenus",
      JSON.stringify(incomingMenu)
    );

    // Save latest menu notes
    sessionStorage.setItem(
      "menuNotes",
      JSON.stringify(incomingMenuNotes)
    );

    const selectedTemplate = templates.find(
      (t) => String(t._id) === String(template)
    );

    navigate("/summary", {
      state: {
        eventDetails,
        template,
        templateName:
          selectedTemplate?.templateName ||
          selectedTemplate?.name,
        templateImage:
          selectedTemplate?.previewImage,
        selectedMenu: incomingMenu,
        menuNotes: incomingMenuNotes,
        editMode,
        eventId,
        userType
      }
    });

  } catch (err) {

    console.error(err);

    setLoading(false);

    alert("Failed to open preview");

  }

};

const handleUpdateMenu = async () => {

  setLoading(true);

  const selectedMenu = incomingMenu;
  const menuNotes = incomingMenuNotes;

  try {

    const response = await fetch(
      `/updateEvent/${eventId}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          authorization:
            sessionStorage.getItem("adminToken")||
            sessionStorage.getItem("userToken")
        },
        body: JSON.stringify({
          ...(eventDetails || {}),
          template,
          templateName:currentTemplate?.templateName,
          selectedMenu,
          menuNotes 
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to update menu");
    }

    alert(data.message || "Menu updated successfully");

    // Clear session ONLY after successful update
    sessionStorage.removeItem("bookingData");
    sessionStorage.removeItem("selectedMenus");
    sessionStorage.removeItem("menuNotes");
    sessionStorage.removeItem("templateSettings");
    sessionStorage.removeItem("templateHTML");
    sessionStorage.removeItem("eventFlowId");
    sessionStorage.removeItem("bookingInProgress");
    sessionStorage.removeItem("editMode");

    if (userType === "admin") {
      navigate("/allEvents");
    } else {
      navigate("/events");
    }

  } catch (err) {

    setLoading(false);

    console.log(err);
    alert(err.message || "Failed to update menu");

  }
};

  const selectedCategories = Object.keys(incomingMenu)
  .filter(category => incomingMenu[category]?.length > 0);

  const itemFont = fontsize ? `${fontsize}px` : "16px";
  const headerFont = headingsize ? `${headingsize}px` : "30px";



  return (
    <div className="menu-main-container">
      <h1 className="page-title">Catering Menu Card Generator</h1>

      {/* TOP PANEL */}
      <div className="top-panel">

        <div className="control-box control-box-1">
          <label>Select Template</label>

          <div className="template-carousel">

            <button
              type="button"
              className="arrow-btn"
              onClick={prevTemplate}
            >
              ❮
            </button>

            <div className="template-preview">

            {
            currentTemplate?.previewImage && (
            <img
            src={currentTemplate.previewImage}
            alt="template"
            className="template-thumb"
            />
            )
            }

            <p className="template-name">
                {currentTemplate?.templateName}
            </p>

            </div>

            <button
              type="button"
              className="arrow-btn"
              onClick={nextTemplate}
            >
              ❯
            </button>

          </div>
        </div>

        <div className="control-box control-box-4">
          <label>Heading Size</label>
          <input
            type="number"
            min="30" 
            max="40" 
            placeholder="30"
            onChange={(e) => setHeadingsize(e.target.value)}
          />

          <div className="font-carousel">

          <button
            type="button"
            className="arrow-btn"
            onClick={prevHeadingFont}
          >
            ❮
          </button>

          <div className="font-preview">

            <span
              className="font-name"
              style={{
                fontFamily: headingfont
              }}
            >
              {headingfont === "SilkSerif"
                ? "Silk Serif"
                : "Cormorant"}
            </span>

          </div>

          <button
            type="button"
            className="arrow-btn"
            onClick={nextHeadingFont}
          >
            ❯
          </button>

        </div>
        </div>

        <div className="control-box control-box-5">
          <label>Item Size</label>
          <input
            type="number"
            min="16" 
            max="25" 
            placeholder="16"
            onChange={(e) => setFontsize(e.target.value)}
          />

          <div className="font-carousel">

            <button
              type="button"
              className="arrow-btn"
              onClick={prevItemFont}
            >
              ❮
            </button>

            <div className="font-preview">

              <p
                className="font-name"
                style={{ fontFamily: font }}
              >
                {font === "Monsterrat"
                  ? "Monsterrat"
                  : "Futura"}
              </p>

            </div>

            <button
              type="button"
              className="arrow-btn"
              onClick={nextItemFont}
            >
              ❯
            </button>

          </div>
        </div>

        {/* <button className="download-btn" onClick={downloadPDF}>
          Download PDF
        </button> */}
      </div>

      {/* TEMPLATE AREA */}
      <div className="templates-wrapper">

        {selectedCategories.map((category, index) => (

        <div
            key={index}
            className="template-card"
            style={{
            backgroundImage: currentTemplate?.previewImage ? `url(${currentTemplate.previewImage})`:"none",
            backgroundSize:"cover",
            backgroundPosition:"center"
            }}
        >
            <div className="template-content">

            <div className="menu-list">

                <div className="category-section">

                <h3
                    className="menu-heading"
                    style={{
                    color:currentTemplate?.defaultTextColor,
                    fontSize: headerFont,
                    fontFamily: headingfont
                    }}
                >
                    {category}
                </h3>

                {incomingMenu[category]?.map((item, i) => (

                    <h4
                    key={i}
                    className="menu-items"
                    style={{
                        color:currentTemplate?.defaultTextColor,
                        fontSize: itemFont,
                        fontFamily: font
                    }}
                    >
                    • {item}
                    </h4>

                ))}

                </div>

            </div>

            </div>

        </div>

        ))}

</div>

      <div className="preview-btn-div">

          <button
            className="btn btn-secondary"
            onClick={handleBack}
            disabled={loading}
          >
          Back
          </button>

          <button
              className="preview-btn btn btn-primary"
              onClick={handlePreview}
              disabled={loading}
          >
              {loading ? "Loading..." : "Preview"}
          </button>

          {editMode && (

              <button
                  className="btn btn-success"
                  onClick={handleUpdateMenu}
                  disabled={loading}
              >
                  {loading ? "Updating..." : "Update"}
              </button>

          )}

      </div>

    </div>
  );
}

export default App;