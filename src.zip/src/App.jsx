import { useState } from 'react'
import { BrowserRouter, Route, Routes } from "react-router-dom"
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
//import './App.css'
import Navbar from './Navbar'
import ScrollToTop from './ScrollToTop'
import SignUp from './Signup'
import Login from './Login'
import Admin from './Admin'
import Addtemp from './Addtemp'
import Temp from './Temp'
// import MenuCardGenerator from './MenuCardGenerator'
import Booking from './Booking'
import MenuSection from './MenuSection'
import Events from './Events'
import CreateUser from './CreateUser'
import CreateAdmin from './CreateAdmin'
import ForgotPassword from './ForgotPassword'
import AllEvents from './AllEvents'
import Summary from './Summary'
import MenuSelection from './MenuSelection'
import TemplateSelection from './TemplateSelection'
import VerifyOtp from './Verifyotp'
import ResetPassword from './Resetpassword'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>

          <ScrollToTop />
          <Navbar/>

          <Routes>

              {/* <Route path="/signup" element = {<SignUp/>}/>               */}
              <Route path="/" element = {<Login/>}/>              
              <Route path="/admin" element = {<Admin/>}/>                       
              {/* <Route path="/menuCardGenerator" element = {<MenuCardGenerator/>}/>               */}
              <Route path="/booking" element = {<Booking/>}/>              
              <Route path="/addTemplate" element = {<Addtemp/>}/>              
              <Route path="/temp" element = {<Temp/>}/>              
              <Route path="/allEvents" element = {<AllEvents/>}/>              
              <Route path="/events" element = {<Events/>}/>                       
              <Route path="/menuSection" element = {<MenuSection/>}/>              
              <Route path="/menuSelection" element = {<MenuSelection/>}/>              
              <Route path="/menuSelection/:id" element = {<MenuSelection/>}/>              
              <Route path="/templateSelection" element = {<TemplateSelection/>}/> 
              <Route path="/createUser" element = {<CreateUser/>}/>              
              <Route path="/createAdmin" element = {<CreateAdmin/>}/>              
              <Route path="/forgotPassword" element = {<ForgotPassword/>}/>              
              <Route path="/verifyOtp" element = {<VerifyOtp/>}/>              
              <Route path="/resetPassword" element = {<ResetPassword/>}/>              
              <Route path="/summary" element = {<Summary/>}/>        
              {/* <Route path="/menuCardGenerator/:id" element={<MenuCardGenerator />}/>       */}

          </Routes>

      </BrowserRouter>
    </>
  )
}

export default App
