import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useNavigate } from "react-router-dom"
import "./CreateAdmin.css";

export default function CreateAdmin() {

    const navigate = useNavigate()
    const [username, setUsername] = useState("");
    const [officialEmail, setOfficialEmail] = useState("");
    const [department, setDepartment] = useState("");
    const [employeeID, setEmployeeID] = useState("");
    const [password, setPassword] = useState("");

    const handleCreateAdmin = async (e) => {

        e.preventDefault();

        const token =
        sessionStorage.getItem("adminToken");

        const response = await fetch(
            "/createAdmin",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    authorization: token
                },
                body: JSON.stringify({
                    username,
                    officialEmail,
                    department,
                    employeeID,
                    password
                })
            }
        );

        const data = await response.json();

        alert(data.message);

        if(data.message === "Admin Created Successfully"){

            setUsername("");
            setOfficialEmail("");
            setDepartment("");
            setEmployeeID("");
            setPassword("");

        }
        else{
            setUsername("");
            setOfficialEmail("");
            setDepartment("");
            setEmployeeID("");
            setPassword("");
        }
    };

    return (
        <>
            <div className="admin1-container">

                <div className=" d-flex justify-content-start w-100 px-5">
                    <NavLink to="/allEvents">
                        <button className="btn btn-secondary">
                            ← Back
                        </button>
                    </NavLink>
                </div>

                <div className="admin1-card">

                    <div className="admin1-form-section">

                        <h1>Create admin</h1>

                        <p>
                            Create a new administrator account
                        </p>

                        <form onSubmit={handleCreateAdmin}>

                            <input
                                type="text"
                                placeholder="Admin Name"
                                value={username}
                                required
                                onChange={(e) =>
                                    setUsername(e.target.value)
                                }
                            />

                            <input
                                type="email"
                                placeholder="Official Email"
                                value={officialEmail}
                                required
                                onChange={(e) =>
                                    setOfficialEmail(e.target.value)
                                }
                            />

                            <input
                                type="text"
                                placeholder="Department"
                                value={department}
                                required
                                onChange={(e) =>
                                    setDepartment(e.target.value)
                                }
                            />

                            <input
                                type="text"
                                placeholder="Employee ID"
                                value={employeeID}
                                required
                                onChange={(e) =>
                                    setEmployeeID(e.target.value)
                                }
                            />

                            <input
                                type="password"
                                placeholder="Default Password"
                                value={password}
                                required
                                onChange={(e) =>
                                    setPassword(e.target.value)
                                }
                            />

                            <button type="submit">
                                Create admin
                            </button>

                        </form>

                    </div>

                </div>

            </div>
        </>
    );
}